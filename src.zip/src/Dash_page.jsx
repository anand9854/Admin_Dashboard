import React, {useState} from 'react';
import Header from './Assets/Header';
import Sidebar from './Assets/Sidebar';
import Home from './Assets/Home';
import './App.css';

const Dash = () =>{
    const [openSidebarToggle, setOpenSidebarToggle] = useState(false);

    const OpenSidebar = () => {
      setOpenSidebarToggle(!openSidebarToggle);
    };

    
    return(
      <div className='grid-container'>
        <Header OpenSidebar={OpenSidebar}/>
        <Sidebar openSidebarToggle={openSidebarToggle} OpenSidebar={OpenSidebar}/>
        <Home />       
      </div>
    );
};

export default Dash;