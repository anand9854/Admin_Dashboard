import React from 'react';
import Dash from './Dash_page';
function App() {
  return (
    <Dash/>
  );
};

export default App;
