import React from 'react';
import { BsFillBox2Fill, BsCashCoin } from 'react-icons/bs';
import 
 { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } 
 from 'recharts';
 import { FaShoppingCart } from "react-icons/fa";
import image_cart from './cart_design.png';
import '../App.css';
// import logo from './logo.png';
const Home = () => {
    const data = [
        {name: 'JAN',SALES: 4000,pv: 2400,amt: 2400,},
        {name: 'FEB',SALES: 3000,pv: 1398,amt: 2210,},
        {name: 'MAR',SALES: 2000,pv: 9800,amt: 2290,},
        {name: 'APR',SALES: 2780,pv: 3908,amt: 2000,},
        {name: 'MAY',SALES: 1890,pv: 4800,amt: 2181,},
        {name: 'JUN',SALES: 2390,pv: 3800,amt: 2500,},
        {name: 'JUL',SALES: 3490,pv: 4300,amt: 2100,},
      ];



      
  return (
    <main className='main-container'>
        <div className='main-title'>
            <h3>REEGAN SUPERMARKET</h3>
            {/* <img src={logo} alt="logo"></img> */}
        </div>
        <div className='main-cards'>
            <div className='card'>
                <div className='card-inner'>
                    <h3>Total Sales Value</h3>
                    <FaShoppingCart className='card_icon'/>
                </div>
                <h1>0</h1>
            </div>
            <div className='card'>
                <div className='card-inner'>
                    <h3>Total Purchase Value</h3>
                    <BsFillBox2Fill className='card_icon'/>
                </div>
                <h1>0</h1>
            </div>
            <div className='card'>
                <div className='card-inner'>
                    <h3>Total Cash Value</h3>
                    <BsCashCoin className='card_icon'/>
                </div>
                <h1>0</h1>
            </div>
            <div className='card'>
                <div className='card-inner'>
                    <h3>Total Credit Value</h3>
                    <BsCashCoin className='card_icon'/>
                </div>
                <h1>0</h1>
            </div>
            <div className='card'>
                <div className='card-inner'>
                    <h3>Total Highest Bill</h3>
                    <FaShoppingCart className='card_icon'/>
                </div>
                <h1>0</h1>
            </div>
            <div className='card'>
                <div className='card-inner'>
                    <h3>Total Bill Count</h3>
                    <FaShoppingCart className='card_icon'/>
                </div>
                <h1>0</h1>
            </div>
            <div className='card'>
                <div className='card-inner'>
                    <h3>Today Expenses</h3>
                    <BsCashCoin className='card_icon'/>
                </div>
                <h1>0</h1>
            </div>
            <div>
                
                    <img src={image_cart} alt="image_cart" className='image_cart'></img>
                
            </div>
        </div>
        <div className='charts'>
            
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                    width={500}
                    height={300}
                    data={data}
                    margin={{
                    top: 10,
                    right: 30,
                    left: 0,
                    bottom: 0,
                }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="SALES" stroke="#8884d8" fill="#8884d8" />
                </AreaChart>
            </ResponsiveContainer>
            <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          width={500}
          height={300}
          data={data}
          margin={{
            top: 10,
            right: 30,
            left: 0,
            bottom: 0,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Area type="monotone" dataKey="SALES" stackId="1" stroke="#8884d8" fill="#8884d8" />
          <Area type="monotone" dataKey="pv" stackId="1" stroke="#82ca9d" fill="#82ca9d" />
          <Area type="monotone" dataKey="amt" stackId="1" stroke="#ffc658" fill="#ffc658" />
        </AreaChart>
      </ResponsiveContainer>
        </div>
    </main>
  )
}
export default Home;