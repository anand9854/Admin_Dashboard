import { React, useState} from 'react';
import { BsCart3, BsGrid1X2Fill, BsFillArchiveFill, BsFillGrid3X3GapFill, BsPeopleFill} from 'react-icons/bs';
import { IoIosArrowDown, IoIosArrowForward } from 'react-icons/io';

// use state for master side bar
const Sidebar = ({ openSidebarToggle, OpenSidebar }) => {
  const [expanded, setExpanded] = useState({
    master: false,
    transaction: false,
    reports: false
});
const toggleExpand = (section) => {
    setExpanded((prevExpanded) => ({
        ...prevExpanded,
        [section]: !prevExpanded[section],
    }));
};

// Use state for transaction
const [expanded2, setExpanded2] = useState({
  master: false,
  transaction: false,
  reports: false
});
const toggleExpand2 = (section) => {
  setExpanded2((prevExpanded) => ({
      ...prevExpanded,
      [section]: !prevExpanded[section],
  }));
};

// use state for reports sidebar
const [expanded3, setExpanded3] = useState({
  master: false,
  transaction: false,
  reports: false
});
const toggleExpand3 = (section) => {
  setExpanded3((prevExpanded) => ({
      ...prevExpanded,
      [section]: !prevExpanded[section],
  }));
};

  return (
    <aside id="sidebar" className={openSidebarToggle ? "sidebar-responsive": ""}>
      <div className='sidebar-title'>
        <div className='sidebar-brand'>
          <BsCart3 className='icon_header'/> LOGIC-PRO
        </div>
        <span className='icon close_icon' onClick={OpenSidebar}>X</span>
      </div>
      <ul className='sidebar-list'>
        <li className='sidebar-list-item'>
          <a href=" ">
            <BsGrid1X2Fill className='icon'/> Dashboard
          </a>
        </li>
        <li className='sidebar-list-item' onClick={()=> toggleExpand('master')}>
          <label>
            <BsFillArchiveFill className='icon'/> Master  {expanded.master ? <IoIosArrowDown /> : <IoIosArrowForward />}
          </label>
        </li>
        {expanded.master && (
                    <ul className='sidebar-sublist'>
                        <li className='sidebar-subitem'><a href=" ">Product Group</a></li>
                        <li className='sidebar-subitem'><a href=" ">Product</a></li>
                        <li className='sidebar-subitem'><a href=" ">User</a></li>
                        <li className='sidebar-subitem'><a href=" ">Ledger Group</a></li>
                        <li className='sidebar-subitem'><a href=" ">Ledger</a></li>
                    </ul>
          )}
        <li className='sidebar-list-item' onClick={()=> toggleExpand2('transaction')}>
          <label>
            <BsFillGrid3X3GapFill className='icon'/> Transaction  {expanded2.transaction ? <IoIosArrowDown /> : <IoIosArrowForward />}
          </label>
        </li>
        {expanded2.transaction && (
                    <ul className='sidebar-sublist'>
                        <li className='sidebar-subitem'><a href=" ">Purchase</a></li>
                        <li className='sidebar-subitem'><a href=" ">Sales</a></li>
                        <li className='sidebar-subitem'><a href=" ">Purchase Return</a></li>
                        <li className='sidebar-subitem'><a href=" ">Sales Return</a></li>
                        <li className='sidebar-subitem'><a href=" ">Estimate</a></li>
                    </ul>
          )}
        <li className='sidebar-list-item' onClick={()=>toggleExpand3('reports')}>
          <label>
            <BsPeopleFill className='icon'/> Reports {expanded3.reports ? <IoIosArrowDown /> : <IoIosArrowForward />}
          </label>
        </li>
        {expanded3.reports && (
                    <ul className='sidebar-sublist'>
                        <li className='sidebar-subitem'><a href=" ">Accounts Report</a></li>
                        <li className='sidebar-subitem'><a href=" ">Stock Report </a></li>
                        <li className='sidebar-subitem'><a href=" ">Transaction Report</a></li>
                        <li className='sidebar-subitem'><a href=" ">GST Report</a></li>
                    </ul>
          )}
        </ul>
    </aside>
  );
}

export default Sidebar;
