import React from 'react';
import { BsFillBellFill, BsFillEnvelopeFill, BsPersonCircle, BsSearch, BsJustify } from 'react-icons/bs';
import SearchBox from './SearchBox';
import './Searchbar.css';
const Header = ({ OpenSidebar }) => {
  const handleSearch = (query) => {
    console.log('Searching for:', query);
  };
  return (
    <header className='header'>
      <div className='menu-icon'>
        <BsJustify className='icon' onClick={OpenSidebar}/>
      </div>
      <div className='header-left'>
        <BsSearch className='icon'/>
      </div>
      <div className="Search_app">
            <SearchBox onSearch={handleSearch} />
      </div>
      <div className='header-right'>
        <BsFillBellFill className='icon'/>
        <BsFillEnvelopeFill className='icon'/>
        <BsPersonCircle className='icon'/>
      </div>
    </header>
  );
}

export default Header;
